package flightmanagementsystem.dao;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import flightmanagementsystem.model.UserAdmin;

@Component
public class UserAdminDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	// Create new admin and update existing admin
	@Transactional
	public void createOrUpdateAdminDetails(UserAdmin userAdmin) {
		this.hibernateTemplate.saveOrUpdate(userAdmin);
	}

	// get the single admin
	public UserAdmin getUserAdminDetails(String username) {
		return this.hibernateTemplate.get(UserAdmin.class, username);
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
}
