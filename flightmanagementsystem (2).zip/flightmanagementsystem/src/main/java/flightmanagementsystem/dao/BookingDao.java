package flightmanagementsystem.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import flightmanagementsystem.model.Booking;

@Component
public class BookingDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	// Create new booking and update existing booking
	@Transactional
	public void createOrUpdateBookingDetails(Booking booking) {
		this.hibernateTemplate.saveOrUpdate(booking);
	}

	// get the single booking
	public Booking getSingleBookingDetail(int bookingId) {
		return this.hibernateTemplate.get(Booking.class, bookingId);
	}

	// get all bookings
	public List<Booking> getAllBookingDetails() {
		List<Booking> bookings = hibernateTemplate.loadAll(Booking.class);
		return bookings;
	}

	// delete a single booking
	@Transactional
	public void deleteBooking(int bookingId) {
		Booking booking = this.hibernateTemplate.load(Booking.class, bookingId);
		this.hibernateTemplate.delete(booking);
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

}