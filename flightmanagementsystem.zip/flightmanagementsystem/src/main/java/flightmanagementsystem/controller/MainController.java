package flightmanagementsystem.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import flightmanagementsystem.dao.BookingDao;
import flightmanagementsystem.dao.CustomerDao;
import flightmanagementsystem.dao.FlightDao;
import flightmanagementsystem.dao.UserAdminDao;
import flightmanagementsystem.model.Booking;
import flightmanagementsystem.model.Customer;
import flightmanagementsystem.model.Flight;
import flightmanagementsystem.model.UserAdmin;

@Controller
public class MainController {

	@Autowired
	private FlightDao flightDao;
	@Autowired
	private CustomerDao customerDao;
	@Autowired
	private BookingDao bookingDao;
	@Autowired
	private UserAdminDao userAdminDao;

	@RequestMapping(value = "/adminLogin")
	public String adminLogin() {
		return "adminLogin";
	}

	@RequestMapping(value = "/customerRegistration")
	public String customerRegistration() {
		return "customerRegistration";
	}

   //mapping our request to the page
	@RequestMapping(value = "/customerLogin")
	public String customerLogin() {
		return "customerLogin";
	}

	/* Admin Operations Part */

	@RequestMapping("/start")
	public String home(Model model) {
		// get all flights
		List<Flight> flights = flightDao.getAllFlightDetails();
		model.addAttribute("allFlights", flights);
		return "index";
	}

	// show flight details page
	@RequestMapping("/add-flight")
	public String addFlight(Model model) {
		model.addAttribute("title", "Add Flight");
		return "addFlightDetails";
	}

	// Handle add flight details form
	@RequestMapping(value = "/handle-flight", method = RequestMethod.POST)
	public RedirectView handleFlight(@ModelAttribute Flight flight, HttpServletRequest httpServletRequest) {
		System.out.println(flight);
		RedirectView redirectView = new RedirectView();
		flightDao.createOrUpdateFlightDetails(flight);

		// httpServletRequest.getContextPath() -> will give you the homepage url
		redirectView.setUrl(httpServletRequest.getContextPath() + "/start");
		return redirectView;
	}

	// delete handler
	// {flightNumber} -> URI Template Variable
	@RequestMapping("/delete/{flightNumber}")
	public RedirectView deleteFlight(@PathVariable("flightNumber") String flightNumber,
			HttpServletRequest httpServletRequest) {
		this.flightDao.deleteFlight(flightNumber);
		RedirectView redirectView = new RedirectView();
		// httpServletRequest.getContextPath() -> will give you the homepage url
		redirectView.setUrl(httpServletRequest.getContextPath() + "/start");
		return redirectView;
	}

	// update form
	// {flightNumber} -> URI Template Variable
	@RequestMapping("/update/{flightNumber}")
	public String updateFlightDetails(@PathVariable("flightNumber") String flightNumber, Model model) {
		Flight oldFlightData = this.flightDao.getSingleFlightDetail(flightNumber);
		model.addAttribute("oldFlightData", oldFlightData);
		return "updateFlightDetails";
	}

	// show new admin page
	@RequestMapping("/add-admin")
	public String addNewAdmin(Model model) {
		model.addAttribute("title", "Add New Admin");
		return "addNewAdmin";
	}

	// Handle add new admin details form
	@RequestMapping(value = "/handle-admin", method = RequestMethod.POST)
	public RedirectView handleAddNewAdmin(@ModelAttribute UserAdmin userAdmin, HttpServletRequest httpServletRequest) {
		System.out.println(userAdmin);
		RedirectView redirectView = new RedirectView();
		userAdminDao.createOrUpdateAdminDetails(userAdmin);

		// httpServletRequest.getContextPath() -> will give you the homepage url
		redirectView.setUrl(httpServletRequest.getContextPath() + "/start");
		return redirectView;
	}

	// update form
	// {flightNumber} -> URI Template Variable
//	@RequestMapping(value = "/validate/{username}", method = RequestMethod.POST)
//	@RequestMapping(value = "/validate/{username}", method = RequestMethod.POST)
//	public String validateAdminLoginDetails(@PathVariable("flightNumber") String flightNumber,
//			@ModelAttribute UserAdmin userAdmin) {
//		System.out.println(userAdmin);
//		this.userAdminDao.getUserAdminDetails(userAdmin.getUsername());
//
//		if (userAdmin != null) {
//
//		}
//
//		return "updateFlightDetails";
//	}

	@RequestMapping(value = "validate/{username}", method = RequestMethod.POST)
	public String validateAdminLoginDetails(@PathVariable("username") String username,
			@ModelAttribute UserAdmin userAdmin, HttpServletRequest httpServletRequest) {
		System.out.println(userAdmin);
		UserAdmin currentInputAdmin = this.userAdminDao.getUserAdminDetails(username);

		System.out.println(userAdmin.getId());
		System.out.println(userAdmin.getUsername());
		System.out.println(userAdmin.getPassword());

		if (userAdmin.getUsername().equals(currentInputAdmin.getUsername())
				&& (userAdmin.getPassword().equals(currentInputAdmin.getPassword()))) {
			return "index";
		}

		return "adminLogin";
	}

	/* Customer Part */

	// get all booking
	@RequestMapping("/customerHome")
	public String getAllBookings(Model model) {
		// get all flights
		List<Booking> bookings = bookingDao.getAllBookingDetails();
		model.addAttribute("allBookings", bookings);
		return "customerHomePage";
	}

	// Handle add customer details form
	@RequestMapping(value = "/handle-customer", method = RequestMethod.POST)
	public RedirectView handleCustomer(@ModelAttribute Customer customer, HttpServletRequest httpServletRequest) {
		System.out.println(customer);
		RedirectView redirectView = new RedirectView();
		customerDao.createOrUpdateCustomerDetails(customer);

		// httpServletRequest.getContextPath() -> will give you the homepage url
		redirectView.setUrl(httpServletRequest.getContextPath() + "/start");
		return redirectView;
	}

	/* Flight Booking Details */

	// add booking details
	@RequestMapping("/book-ticket")
	public String bookTicket(Model model) {
		model.addAttribute("title", "Book Ticket");
		return "bookingForm";
	}

	// Handle add booking details form
	@RequestMapping(value = "/handle-booking", method = RequestMethod.POST)
	public RedirectView bookingDetails(@ModelAttribute Booking booking, HttpServletRequest httpServletRequest) {
		System.out.println(booking);
		RedirectView redirectView = new RedirectView();
		bookingDao.createOrUpdateBookingDetails(booking);

		// httpServletRequest.getContextPath() -> will give you the homepage url
		redirectView.setUrl(httpServletRequest.getContextPath() + "/customerHome");
		return redirectView;
	}

	// delete handler
	// {bookingId} -> URI Template Variable
	@RequestMapping("/deleteBooking/{bookingId}")
	public RedirectView deleteBooking(@PathVariable("bookingId") int bookingId, HttpServletRequest httpServletRequest) {
		this.bookingDao.deleteBooking(bookingId);
		RedirectView redirectView = new RedirectView();
		// httpServletRequest.getContextPath() -> will give you the homepage url
		redirectView.setUrl(httpServletRequest.getContextPath() + "/customerHome");
		return redirectView;
	}
}
