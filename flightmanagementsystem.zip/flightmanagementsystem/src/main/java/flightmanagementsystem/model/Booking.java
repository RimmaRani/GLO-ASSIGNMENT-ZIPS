package flightmanagementsystem.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bookingId;
	private int userId; // Foreign Key of customer Id
	private String bookingDate;
	private String passengerName;
	private int passengerAge;
	private String passengerUIN;
	private double passengerLuggage;
	private double bookingTicketPrice;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getPassengerAge() {
		return passengerAge;
	}

	public void setPassengerAge(int passengerAge) {
		this.passengerAge = passengerAge;
	}

	public String getPassengerUIN() {
		return passengerUIN;
	}

	public void setPassengerUIN(String passengerUIN) {
		this.passengerUIN = passengerUIN;
	}

	public double getPassengerLuggage() {
		return passengerLuggage;
	}

	public void setPassengerLuggage(double passengerLuggage) {
		this.passengerLuggage = passengerLuggage;
	}

	public double getBookingTicketPrice() {
		return bookingTicketPrice;
	}

	public void setBookingTicketPrice(double bookingTicketPrice) {
		this.bookingTicketPrice = bookingTicketPrice;
	}

	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", userId=" + userId + ", bookingDate=" + bookingDate
				+ ", passengerName=" + passengerName + ", passengerAge=" + passengerAge + ", passengerUIN="
				+ passengerUIN + ", passengerLuggage=" + passengerLuggage + ", bookingTicketPrice=" + bookingTicketPrice
				+ "]";
	}

}
