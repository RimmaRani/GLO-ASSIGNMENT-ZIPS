package flightmanagementsystem.dao;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import flightmanagementsystem.model.Customer;

@Component
public class CustomerDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	// Create new flight and update existing flight
	@Transactional
	public void createOrUpdateCustomerDetails(Customer customer) {
		this.hibernateTemplate.saveOrUpdate(customer);
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
}
