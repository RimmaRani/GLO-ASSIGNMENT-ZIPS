package com.contact.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.contact.entity.Contact;

@Service
public class ContactServiceImpl implements ContactService {

	// fake list of contact
	List<Contact> list = List.of
			(new Contact(1L, "Sachin@email.com", "Sachin", 1311L),
			new Contact(2L, "reema@email.com", "Reema", 1311L),
			new Contact(3L, "rashmi@email.com", "Rashmi", 131L),
			new Contact(4L, "rani@email.com", "Rani", 13L)
			
					);

	//i nneed contact of that person whose id is passes over here
	@Override
	public List<Contact> getContactsOfUser(Long userId) {
		//gives us the list of contacts of the user whose id is passsed
		return list.stream().filter(contact->contact.getUserId().equals(userId)).collect(Collectors.toList());
	}

}
