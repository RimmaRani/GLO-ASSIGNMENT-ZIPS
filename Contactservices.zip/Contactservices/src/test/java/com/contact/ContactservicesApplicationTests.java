package com.contact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactservicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
