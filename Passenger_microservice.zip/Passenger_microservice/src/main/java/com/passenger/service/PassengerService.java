package com.passenger.service;

import com.passenger.common.Booking;
import com.passenger.common.TransactionRequest;
import com.passenger.common.TransactionResponse;
import com.passenger.entity.Passenger;
import com.passenger.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PassengerService {

    @Autowired
    private PassengerRepository repository;

    @Autowired
    private RestTemplate template;

    public TransactionResponse savePassenger(TransactionRequest request){
        String response="";
        Passenger passenger=request.getPassenger();
        Booking booking=request.getBooking();
        booking.setPnrNumber(passenger.getPnrNumber());
        passenger.setPnrNumber(booking.getPnrNumber());
        booking.setAmount(passenger.getTicketCost());


        //rest call
        Booking bookingResponse = template.postForObject("http://BOOKING-SERVICE/booking/doBooking", booking, Booking.class);

        response=bookingResponse.getBookingStatus().equals("Success")?"Payment Processing Successful and Flight is Booked":
                "There is FAILURE..Try Again";
        repository.save(passenger);
        return new TransactionResponse(passenger, bookingResponse.getAmount(),bookingResponse.getTransactionId(), response);
    }
}
