package com.passenger.controller;

import com.passenger.common.TransactionRequest;
import com.passenger.common.TransactionResponse;
import com.passenger.service.PassengerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/passenger")
public class PassengerController {

    @Autowired
    private PassengerService service;

    @PostMapping("/book-passenger")
    public TransactionResponse bookPassenger(@RequestBody TransactionRequest request){
        return service.savePassenger(request);
    }

    //do a rest call to booking api

}
