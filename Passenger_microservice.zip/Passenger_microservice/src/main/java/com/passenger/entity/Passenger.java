package com.passenger.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PASSENGERSS_TB")
public class Passenger {

    @Id
    @GeneratedValue
    private int pnrNumber;
    private String passengerName;
    private String passengerAge;
    private double lugguage;
    private double ticketCost;
    private String source;
    private String destination;

    public Passenger() {
    }

    public Passenger(int pnrNumber, String passengerName, String passengerAge, double lugguage, double ticketCost, String source, String destination) {
        this.pnrNumber = pnrNumber;
        this.passengerName = passengerName;
        this.passengerAge = passengerAge;
        this.lugguage = lugguage;
        this.ticketCost = ticketCost;
        this.source = source;
        this.destination = destination;
    }

    public int getPnrNumber() {
        return this.pnrNumber;
    }

    public void setPnrNumber(int pnrNumber) {
        this.pnrNumber = pnrNumber;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getPassengerAge() {
        return passengerAge;
    }

    public void setPassengerAge(String passengerAge) {
        this.passengerAge = passengerAge;
    }

    public double getLugguage() {
        return lugguage;
    }

    public void setLugguage(double lugguage) {
        this.lugguage = lugguage;
    }

    public double getTicketCost() {
        return ticketCost;
    }

    public void setTicketCost(double ticketCost) {
        this.ticketCost = ticketCost;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }
}
