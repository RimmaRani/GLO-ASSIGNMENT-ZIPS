/**
 * @author Gagandeep Singh
 * @email singh.gagandeep3911@gmail.com
 * @create date 2020-09-19 22:13:12
 * @modify date 2020-09-19 22:13:12
 * @desc Quality Status
 */
package com.cg.inventoryrawmaterialorderservice.enums;

public enum QualityCheck {
  Passed, Failed
}
