package com.cg.inventoryrawmaterialorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventoryRawmaterialOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventoryRawmaterialOrderServiceApplication.class, args);
	}

}
