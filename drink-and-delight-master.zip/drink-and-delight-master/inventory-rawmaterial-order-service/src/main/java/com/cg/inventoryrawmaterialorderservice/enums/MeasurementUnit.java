package com.cg.inventoryrawmaterialorderservice.enums;

public enum MeasurementUnit {
  Kilogram, Litre
}
