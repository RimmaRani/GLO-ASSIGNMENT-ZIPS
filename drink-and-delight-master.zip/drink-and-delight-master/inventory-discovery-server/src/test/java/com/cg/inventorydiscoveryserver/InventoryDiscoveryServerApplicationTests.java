package com.cg.inventorydiscoveryserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryDiscoveryServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
