package com.cg.inventorydatabaseservice.enums;

public enum MeasurementUnit {
  Kilogram, Litre
}
