package com.cg.inventorygatewayserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventoryGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
