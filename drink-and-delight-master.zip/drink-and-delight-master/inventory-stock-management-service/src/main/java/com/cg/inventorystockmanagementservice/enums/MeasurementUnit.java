package com.cg.inventorystockmanagementservice.enums;

public enum MeasurementUnit {

	Kilogram, Litre
	
}
