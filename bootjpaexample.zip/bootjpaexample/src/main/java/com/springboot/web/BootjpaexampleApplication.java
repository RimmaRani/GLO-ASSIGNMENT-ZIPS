package com.springboot.web;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.springboot.web.dao.UserRepository;
import com.springboot.web.entities.User;

@SpringBootApplication
public class BootjpaexampleApplication {

	public static void main(String[] args) {
		// IOC
		ApplicationContext context = SpringApplication.run(BootjpaexampleApplication.class, args);

		// DI
		UserRepository userRepository = context.getBean(UserRepository.class);

		// Assigning the values to the constructor--database object
		User userone = new User();
		userone.setName("Sachin");
		userone.setCity("Banglore");
		userone.setStatus("Lead");
		User userinfo = userRepository.save(userone);
		System.out.println(userone);

		// CREATE or Adding second value
		User usertwo = new User();
		usertwo.setName("Sourav");
		usertwo.setCity("Westbengal");
		usertwo.setStatus("BCCI");
		User userdisplay = userRepository.save(usertwo);
		System.out.println(userdisplay);

		// READ-- single user
		List<User> users = List.of(userone);
		Iterable<User> result = userRepository.saveAll(users);
		result.forEach(user -> {
			System.out.println(user);
		});
		// userRepository.save(null);

		// update the record---we need to find (Exits)
		Optional<User> optional = userRepository.findById(8);
		User user = optional.get(); // true
		user.setName("Abhay");
		user.setCity("Jharkhad");
		User display = userRepository.save(user);
		System.out.println(display);

		// how to get the data
		// findById();

		Iterable<User> itr = userRepository.findAll();
		Iterator<User> iterator = itr.iterator();
		while (iterator.hasNext()) {
			User userobj = iterator.next();
			System.out.println(userobj);
		}

		
		 // delete the user 
		 userRepository.deleteById(7);
		 System.out.println("Id 7 is been deleted");
		 

		/*
		 * //deleteAll Iterable<User> allusers=userRepository.findAll();
		 * allusers.forEach(user->{System.out.println(user);});
		 * userRepository.deleteAll(allusers);
		 * System.out.println("All records are wiped");
		 */

	}

}
