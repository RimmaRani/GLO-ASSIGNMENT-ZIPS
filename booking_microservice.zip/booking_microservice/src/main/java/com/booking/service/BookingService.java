package com.booking.service;

import com.booking.entity.Booking;
import com.booking.repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;
import java.util.UUID;

@Service
public class BookingService {

    @Autowired
    private BookingRepository repository;

    public Booking doBooking(Booking booking){
        booking.setBookingStatus(bookingProcessing());
        booking.setTransactionId(UUID.randomUUID().toString());
        return repository.save(booking);
    }

    public String bookingProcessing() {
        //api should be third party payment gateway
        return new Random().nextBoolean()?"Success":"false";
    }

    public Booking findBookingById(int pnrNumber) {
        return repository.findById(pnrNumber);
    }
}
