package com.booking.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BOOKINGS_TB")
public class Booking {
    @Id
    @GeneratedValue
    private int id;
    private String bookingStatus;
    private String transactionId;
    private int pnrNumber;
    private double amount;

    public Booking() {
    }

    public Booking(int id, String bookingStatus, String transactionId, int pnrNumber, double amount) {
        this.id = id;
        this.bookingStatus = bookingStatus;
        this.transactionId = transactionId;
        this.pnrNumber = pnrNumber;
        this.amount = amount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBookingStatus() {
        return bookingStatus;
    }

    public void setBookingStatus(String bookingStatus) {
        this.bookingStatus = bookingStatus;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public int getPnrNumber() {
        return pnrNumber;
    }

    public void setPnrNumber(int pnrNumber) {
        this.pnrNumber = pnrNumber;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }
}
