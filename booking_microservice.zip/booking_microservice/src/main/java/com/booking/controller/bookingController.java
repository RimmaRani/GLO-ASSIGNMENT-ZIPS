package com.booking.controller;

import com.booking.entity.Booking;
import com.booking.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/booking")
public class bookingController {

    @Autowired
    private BookingService service;

    @PostMapping("/doBooking")
    public Booking doBooking(@RequestBody Booking booking){
        return service.doBooking(booking);
    }

    @GetMapping("/{pnrNumber}")
    public Booking findBookingById(@PathVariable int pnrNumber){
        return service.findBookingById(pnrNumber);
    }

}
