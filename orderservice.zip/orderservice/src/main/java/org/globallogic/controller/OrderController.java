package org.globallogic.controller;

import org.globallogic.common.TransactionRequest;
import org.globallogic.common.TransactionResponse;
import org.globallogic.entity.Order;
import org.globallogic.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderService service;
	
	@PostMapping("/orders")
	public TransactionResponse bookOrder(@RequestBody TransactionRequest request) {
		
		
		return service.saveOrder(request);
		
		//do a rest call to payment and pass the orderid
	}
}
