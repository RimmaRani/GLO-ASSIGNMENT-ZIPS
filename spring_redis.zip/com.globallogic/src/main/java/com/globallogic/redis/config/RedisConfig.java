package com.globallogic.redis.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.repository.configuration.EnableRedisRepositories;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.web.client.RestTemplate;

@Configuration
@EnableRedisRepositories
public class RedisConfig {

    //here we are establishing the connection
    @Bean
    public JedisConnectionFactory connectionFactory(){  //we are connecting the jedis connection factory
        //I need to connect the data using redis server:6379
        RedisStandaloneConfiguration configuration=new RedisStandaloneConfiguration(); //create the object of redisStandalone
        configuration.setHostName("localhost"); //setting the hostname
        configuration.setPort(6379); //setting port number
        return  new JedisConnectionFactory(configuration);//return configuration to JedisconnectionFactory
    }

    //To access the redis server from our application
    //So redis provide provide one template i.e. redis template
    @Bean
    @Primary
    public RedisTemplate<String, Object> redisTemplate(){//we create object of redis template and string is as key and object is as values
        //we are talking with Hibernate properties
        RedisTemplate<String, Object> template=new RedisTemplate<>();
        //we need to establish a db connection
        //need to add the connection factory to the template
        template.setConnectionFactory(connectionFactory());//connectionFactory is the method return the jedisconnectionfactory
        //serialization (change the key serializer to string serializer)
        template.setKeySerializer(new StringRedisSerializer());
        //I need to map it as key and value pair
        template.setHashKeySerializer(new StringRedisSerializer());
        template.setHashKeySerializer(new JdkSerializationRedisSerializer());
        //Now I need set the values
        template.setValueSerializer(new JdkSerializationRedisSerializer());
        //enable the Transaction support
        template.setEnableTransactionSupport(true);
        //setting all the propertiess
        template.afterPropertiesSet();
        return template;
    }
}

//we create the jedisconnectionfactory and created the redis template through which we can access to the redis servers