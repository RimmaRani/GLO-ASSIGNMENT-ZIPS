package org.globallogic.os.api.controller;

import org.globallogic.os.api.entity.Order;
import org.globallogic.os.api.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/order")
public class Ordercontroller {

	@Autowired
	private OrderService service;
	
	@PostMapping("/bookorder")
	public ResponseEntity<Order> saveOrderData(@RequestBody Order order){
	return new ResponseEntity<Order>(service.saveOrder(order), HttpStatus.CREATED);
	}
}
	

