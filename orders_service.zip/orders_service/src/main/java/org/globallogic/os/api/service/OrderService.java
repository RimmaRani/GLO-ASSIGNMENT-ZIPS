package org.globallogic.os.api.service;

import org.globallogic.os.api.entity.Order;
import org.globallogic.os.api.repository.orderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

	@Autowired
	private orderRepository repository;

	public Order saveOrder(Order order) {
		return repository.save(order);

	}
}
