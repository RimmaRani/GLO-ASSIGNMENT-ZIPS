package com.flight.service;

import java.util.List;

import com.flight.model.Flight;

public interface FlightService {
	 void createOrUpdateFlightDetails(Flight flight);
	 Flight getSingleFlightDetail(String flightNumber); 
	 List<Flight> getAllFlightDetails();
	 void deleteFlight(String flightNumber);
}
