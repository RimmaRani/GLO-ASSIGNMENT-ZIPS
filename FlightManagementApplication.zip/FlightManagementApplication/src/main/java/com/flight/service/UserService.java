package com.flight.service;


import com.flight.model.Login;
import com.flight.model.User;

public interface UserService {
	
	int register(User user);
	
	User validateUser(Login login);
}
