package com.flight.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flight.dao.FlightDao;
import com.flight.model.Flight;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	public FlightDao flightDao;

	public void createOrUpdateFlightDetails(Flight flight) {
		flightDao.createOrUpdateFlightDetails(flight);
	}

	public List<Flight> getAllFlightDetails() {
		return flightDao.getAllFlightDetails();
	}

	public void deleteFlight(String flightNumber) {
		flightDao.deleteFlight(flightNumber);

	}

	public Flight getSingleFlightDetail(String flightNumber) {
		return flightDao.getSingleFlightDetail(flightNumber);
	}

}
