package com.flight.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import com.flight.dao.FlightDao;
import com.flight.model.Flight;

@Controller
public class FlightController {
	@Autowired
	private FlightDao flightDao;

	@RequestMapping("/start")
	public String home(Model model) {
		// get all flights
		List<Flight> flights = flightDao.getAllFlightDetails();
		model.addAttribute("allFlights", flights);
		return "MainView";
	}

	// show flight details page
	@RequestMapping("/add-flight")
	public String addFlight(Model model) {
		model.addAttribute("title", "Add Flight");
		return "addFlightDetails";
	}

	// Handle add flight details form
	@RequestMapping(value = "/handle-flight", method = RequestMethod.POST)
	public RedirectView handleFlight(@ModelAttribute Flight flight, HttpServletRequest httpServletRequest) {
		System.out.println(flight);
		RedirectView redirectView = new RedirectView();
		flightDao.createOrUpdateFlightDetails(flight);

		// httpServletRequest.getContextPath() -> will give you the homepage url
		redirectView.setUrl(httpServletRequest.getContextPath() + "/start");
		return redirectView;
	}

	// delete handler
	// {flightNumber} -> URI Template Variable
	@RequestMapping("/delete/{flightNumber}")
	public RedirectView deleteFlight(@PathVariable("flightNumber") String flightNumber,
			HttpServletRequest httpServletRequest) {
		this.flightDao.deleteFlight(flightNumber);
		RedirectView redirectView = new RedirectView();
		// httpServletRequest.getContextPath() -> will give you the homepage url
		redirectView.setUrl(httpServletRequest.getContextPath() + "/start");
		return redirectView;
	}

	// update form
	// {flightNumber} -> URI Template Variable
	@RequestMapping("/update/{flightNumber}")
	public String updateFlightDetails(@PathVariable("flightNumber") String flightNumber, Model model) {
		Flight oldFlightData = this.flightDao.getSingleFlightDetail(flightNumber);
		model.addAttribute("oldFlightData", oldFlightData);
		return "updateFlightDetails";
	}
}
