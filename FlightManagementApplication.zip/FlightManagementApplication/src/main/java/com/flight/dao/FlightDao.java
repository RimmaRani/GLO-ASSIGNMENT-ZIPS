package com.flight.dao;

import java.util.List;

import com.flight.model.Flight;

public interface FlightDao {

	void createOrUpdateFlightDetails(Flight flight);

	Flight getSingleFlightDetail(String flightNumber);

	List<Flight> getAllFlightDetails();

	void deleteFlight(String flightNumber);

}
