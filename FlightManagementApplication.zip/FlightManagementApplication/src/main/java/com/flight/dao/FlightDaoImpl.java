package com.flight.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.flight.model.Flight;

@Component
@Repository
public class FlightDaoImpl implements FlightDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

	// Create new flight and update existing flight
	@Transactional
	public void createOrUpdateFlightDetails(Flight flight) {
		this.hibernateTemplate.saveOrUpdate(flight);
	}

	// get the single flight
	public Flight getSingleFlightDetail(String flightNumber) {
		return this.hibernateTemplate.get(Flight.class, flightNumber);
	}

	// get all flights
	public List<Flight> getAllFlightDetails() {
		List<Flight> flights = hibernateTemplate.loadAll(Flight.class);
		return flights;
	}

	@Transactional
	public void deleteFlight(String flightNumber) {
		Flight flight = this.hibernateTemplate.load(Flight.class, flightNumber);
		this.hibernateTemplate.delete(flight);
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

}
