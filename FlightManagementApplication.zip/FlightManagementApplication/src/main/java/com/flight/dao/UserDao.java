package com.flight.dao;

import com.flight.model.Login;
import com.flight.model.User;

public interface UserDao {
	 int register(User user);
	 User validateUser(Login login);
	
}
