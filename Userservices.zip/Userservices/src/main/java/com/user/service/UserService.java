package com.user.service;

import com.user.entity.User;

public interface UserService {

	// we write methods here that we need in the user class
	// Get method
	public User getUser(Long id); // abstract class
}
