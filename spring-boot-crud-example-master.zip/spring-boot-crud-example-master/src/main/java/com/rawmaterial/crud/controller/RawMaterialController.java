package com.rawmaterial.crud.controller;

import com.rawmaterial.crud.entity.RawMaterial;
import com.rawmaterial.crud.service.RawMaterialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class RawMaterialController {

    @Autowired
    private RawMaterialService service;

    @PostMapping("/addProduct")
    public RawMaterial addProduct(@RequestBody RawMaterial rawMaterial) {
        return service.saveProduct(rawMaterial);
    }

    @PostMapping("/addProducts")
    public List<RawMaterial> addProducts(@RequestBody List<RawMaterial> rawMaterials) {
        return service.saveProducts(rawMaterials);
    }

    @GetMapping("/products")
    public List<RawMaterial> findAllProducts() {
        return service.getProducts();
    }

    @GetMapping("/productById/{rawMaterialId}")
    public RawMaterial findProductById(@PathVariable int rawMaterialId) {
        return service.getProductById(rawMaterialId);
    }

    @GetMapping("/product/{name}")
    public RawMaterial findProductByName(@PathVariable String name) {
        return service.getProductByName(name);
    }

    @PutMapping("/update")
    public RawMaterial updateProduct(@RequestBody RawMaterial rawMaterial) {
        return service.updateProduct(rawMaterial);
    }

    @DeleteMapping("/delete/{rawMaterialId}")
    public String deleteProduct(@PathVariable int rawMaterialId) {
        return service.deleteProduct(rawMaterialId);
    }
}
