package com.rawmaterial.crud.service;

import com.rawmaterial.crud.entity.RawMaterial;
import com.rawmaterial.crud.repository.RawMaterialRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RawMaterialService {
    @Autowired
    private RawMaterialRepository repository;

    public RawMaterial saveProduct(RawMaterial rawMaterial) {
        return repository.save(rawMaterial);
    }

    public List<RawMaterial> saveProducts(List<RawMaterial> rawMaterials) {
        return repository.saveAll(rawMaterials);
    }

    public List<RawMaterial> getProducts() {
        return repository.findAll();
    }

    public RawMaterial getProductById(int rawMaterialId) {
        return repository.findById(rawMaterialId).orElse(null);
    }

    public RawMaterial getProductByName(String name) {
        return repository.findByName(name);
    }

    public String deleteProduct(int rawMaterialId) {
        repository.deleteById(rawMaterialId);
        return "product removed !! " + rawMaterialId;
    }

    public RawMaterial updateProduct(RawMaterial rawMaterial) {
        RawMaterial existingRawMaterial = repository.findById(rawMaterial.getRawmaterialid()).orElse(null);
        existingRawMaterial.setWareHouseId(rawMaterial.getWareHouseId());
        existingRawMaterial.setName(rawMaterial.getName());
        existingRawMaterial.setQuantity(rawMaterial.getQuantity());
        existingRawMaterial.setPrice(rawMaterial.getPrice());
        return repository.save(existingRawMaterial);
    }


}
