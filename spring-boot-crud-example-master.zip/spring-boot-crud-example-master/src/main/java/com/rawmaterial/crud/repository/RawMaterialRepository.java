package com.rawmaterial.crud.repository;

import com.rawmaterial.crud.entity.RawMaterial;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RawMaterialRepository extends JpaRepository<RawMaterial,Integer> {
    RawMaterial findByName(String name);
}

