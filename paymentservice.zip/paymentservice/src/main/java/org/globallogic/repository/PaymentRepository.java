package org.globallogic.repository;

import org.globallogic.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentRepository extends JpaRepository<Payment, Integer>{
	Payment findById(int orderId);
}
