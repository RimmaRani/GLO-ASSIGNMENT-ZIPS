package com.product.service;

import com.product.entity.Product;

public interface ProductService {

	//get product by id
	public Product getProduct(Long id);
}
