package com.product.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.product.entity.Product;

@Service
public class ProductServiceImpl implements ProductService {

	// Product List
	List<Product> list = List.of(new Product(1311L, "Chocklate", "sweet", null),
			new Product(131L, "5 star", "sweet", null), new Product(13L, "Dairy Milk", "sweet", null));

	@Override
	public Product getProduct(Long id) {
    //return the product by id
	return list.stream().filter(product -> product.getpId().equals(id)).findAny().orElse(null);
	}

}
