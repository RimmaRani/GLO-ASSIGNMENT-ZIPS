package com.product.entity;

import java.util.ArrayList;
import java.util.List;

public class Product {

	public Long pId;
	public String pName;
	public String pDesc;

	List<Order> order = new ArrayList<>();

	// parameterized constructor
	public Product(Long pId, String pName, String pDesc, List<Order> order) {
		super();
		this.pId = pId;
		this.pName = pName;
		this.pDesc = pDesc;
		this.order = order;
	}

	// default constructor
	public Product() {
		super();
	}

	// setter and getters
	public Long getpId() {
		return pId;
	}

	public void setpId(Long pId) {
		this.pId = pId;
	}

	public String getpName() {
		return pName;
	}

	public void setpName(String pName) {
		this.pName = pName;
	}

	public String getpDesc() {
		return pDesc;
	}

	public void setpDesc(String pDesc) {
		this.pDesc = pDesc;
	}

	public List<Order> getOrder() {
		return order;
	}

	public void setOrder(List<Order> order) {
		this.order = order;
	}

}
