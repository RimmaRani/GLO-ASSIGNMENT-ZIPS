package com.product.entity;

public class Order {

	private Long oId;
	private String oName;
	private String oAddress;

	// this order is belong to which product
	private Long pId;

	// constructor
	public Order(Long oId, String oName, String oAddress, Long pId) {
		super();
		this.oId = oId;
		this.oName = oName;
		this.oAddress = oAddress;
		this.pId = pId;
	}

	// default constructor
	public Order() {
		super();
	}

	// setter and getter
	public Long getoId() {
		return oId;
	}

	public void setoId(Long oId) {
		this.oId = oId;
	}

	public String getoName() {
		return oName;
	}

	public void setoName(String oName) {
		this.oName = oName;
	}

	public String getoAddress() {
		return oAddress;
	}

	public void setoAddress(String oAddress) {
		this.oAddress = oAddress;
	}

	public Long getpId() {
		return pId;
	}

	public void setpId(Long pId) {
		this.pId = pId;
	}

}
