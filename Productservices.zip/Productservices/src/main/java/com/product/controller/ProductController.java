package com.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.product.entity.Product;
import com.product.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	private ProductService productService;

	@Autowired
	private RestTemplate restTemplate;

	@GetMapping("/{pId}")
	public Product getUser(@PathVariable("pId") Long pId) {
		Product product = this.productService.getProduct(pId);
		// http://localhost:9023/order/product/1311

		List order = this.restTemplate.getForObject("http://localhost:9023/order/product/" + product.getpId(),
				List.class);
		product.setOrder(order);
		return product;

	}
}
