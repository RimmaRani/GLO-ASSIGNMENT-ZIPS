package com.paymentmicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentmicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentmicroserviceApplication.class, args);
	}

}
