package CrudApplication.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class Flight {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String Firstname;
	private String Lastname;
	private String address;
	private int  PhoneNumber ;
	private int ContactPhoneNumber ;
	
	private int DepartureDate;
	private int ReturnDate;
	private String Airline;
	private int Adult;
	public Flight(int id, String firstname, String lastname, String address, int phoneNumber, int contactPhoneNumber,
			 int departureDate, int returnDate, String airline, int adult) {
		super();
		this.id = id;
		Firstname = firstname;
		Lastname = lastname;
		this.address = address;
		PhoneNumber = phoneNumber;
		ContactPhoneNumber = contactPhoneNumber;
		
		DepartureDate = departureDate;
		ReturnDate = returnDate;
		Airline = airline;
		Adult = adult;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return Firstname;
	}
	public void setFirstname(String firstname) {
		Firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public int getContactPhoneNumber() {
		return ContactPhoneNumber;
	}
	public void setContactPhoneNumber(int contactPhoneNumber) {
		ContactPhoneNumber = contactPhoneNumber;
	}
	
	public int getDepartureDate() {
		return DepartureDate;
	}
	public void setDepartureDate(int departureDate) {
		DepartureDate = departureDate;
	}
	public int getReturnDate() {
		return ReturnDate;
	}
	public void setReturnDate(int returnDate) {
		ReturnDate = returnDate;
	}
	public String getAirline() {
		return Airline;
	}
	public void setAirline(String airline) {
		Airline = airline;
	}
	public int getAdult() {
		return Adult;
	}
	public void setAdult(int adult) {
		Adult = adult;
	}
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Flight [id=" + id + ", Firstname=" + Firstname + ", Lastname=" + Lastname + ", address=" + address
				+ ", PhoneNumber=" + PhoneNumber + ", ContactPhoneNumber=" + ContactPhoneNumber +
				 ", DepartureDate=" + DepartureDate + ", ReturnDate=" + ReturnDate + ", Airline="
				+ Airline + ", Adult=" + Adult + "]";
	}
	
		
}
