package CrudApplication.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import CrudApplication.entities.Flight;

@Component
public class FlightDao {
	@Autowired
	private HibernateTemplate hibernateTemplate;

//create
	@Transactional
	public void createFlight(Flight flight) {
		this.hibernateTemplate.save(flight);
	}

//get all details

	public List<Flight> getFlights() {

		List<Flight> flights = this.hibernateTemplate.loadAll(Flight.class);
		return flights;
	}

//delete the single flight
	@Transactional
	public void deleteFlight(int fid) {

		Flight p = this.hibernateTemplate.load(Flight.class, fid);
		this.hibernateTemplate.delete(p);
	}

//get the single flight

	public Flight getFlight(int fid) {
		return this.hibernateTemplate.get(Flight.class, fid);
	}
}