package com.flight.controller;

import com.flight.entity.Flight;
import com.flight.service.FlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Random;

@RestController
@RequestMapping("/flight")
public class FlightController {
    @Autowired
    private FlightService service;
@PostMapping("/doFlight")
    public Flight doFlight(@RequestBody Flight flight){
     return service.doFlight(flight);
    }
    //do a restcall to flight api pass id
    @GetMapping("/{pnrNumber}")
public Flight findFlightHistoryBYpnrNumber(@PathVariable int pnrNumber){
    return service.findFlightHistoryBYpnrNumber(pnrNumber);
    }

}
