package com.flight.service;

import com.flight.entity.Flight;
import com.flight.repository.FlightRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Random;
import java.util.UUID;

@Service
public class FlightService {

    @Autowired
    private FlightRepository repository;

    public Flight doFlight(Flight flight){
        flight.setFlightStatus(flightProcessing());
        flight.setTransactionId(UUID.randomUUID().toString());
        return repository.save(flight);
    }
    public String flightProcessing(){
        //third party gateway
        return new Random().nextBoolean()?"success":"false";
    }

    public Flight findFlightHistoryBYpnrNumber(int pnrNumber) {
        return repository.findByPnrNumber(pnrNumber);
    }
}
