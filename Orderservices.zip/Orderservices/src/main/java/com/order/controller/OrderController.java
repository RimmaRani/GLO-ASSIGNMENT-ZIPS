package com.order.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.entities.Order;
import com.order.service.OrderService;

@RestController
@RequestMapping("order")
public class OrderController {

	@Autowired
	private OrderService orderService;
	
	@RequestMapping("/product/{pId}")  //http://localhost:9091/contact/user/1311
	public List<Order> getOrder(@PathVariable("pId") Long pId){
		return this.orderService.getOrderOfProducts(pId);
		
}}
