package com.order.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.order.entities.Order;
@Service
public class OrderServicesImpl implements OrderService {

	// fake list of order
	List<Order> list = List.of(
			new Order(1L, "Sachin", "Banglore", 1311L),
			new Order(2L, "Reema", "Jammu", 13L),
			new Order(3L, "Rashmi", "Bihar", 131L), 
			new Order(4L, "Rani", "Assam", 13L)

	);

	@Override
	public List<Order> getOrderOfProducts(Long pId) {

		return list.stream().filter(order -> order.getpId().equals(pId)).collect(Collectors.toList());

	}

}
