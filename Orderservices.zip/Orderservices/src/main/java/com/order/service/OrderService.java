package com.order.service;

import java.util.List;

import com.order.entities.Order;

public interface OrderService {

	public List<Order> getOrderOfProducts(Long pId);
}
