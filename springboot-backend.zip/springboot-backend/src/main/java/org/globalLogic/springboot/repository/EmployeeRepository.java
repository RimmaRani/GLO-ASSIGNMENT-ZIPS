package org.globalLogic.springboot.repository;

import org.globalLogic.springboot.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//Spring Data Jpa internallly provides @Repository Annotation
//so we no need to add @REpository annotation to Employee



@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long>{

}
