package org.globalLogic.springboot.service;

import org.globalLogic.springboot.model.Employee;

public interface EmployeeService {

	Employee saveEmployee(Employee employee);
}
