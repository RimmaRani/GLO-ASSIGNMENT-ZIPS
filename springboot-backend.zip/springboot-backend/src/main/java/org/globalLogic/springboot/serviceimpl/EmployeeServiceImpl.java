package org.globalLogic.springboot.serviceimpl;

import org.globalLogic.springboot.model.Employee;
import org.globalLogic.springboot.repository.EmployeeRepository;
import org.globalLogic.springboot.service.EmployeeService;
import org.springframework.stereotype.Service;

@Service
public class EmployeeServiceImpl  implements EmployeeService{
private EmployeeRepository employeeRepository;
	
//1.setter based dependency injection
//2.constructor based dependency injection

public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
	super();
	this.employeeRepository=employeeRepository;
}
	@Override
	public Employee saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeRepository.save(employee);
	}

	

}
