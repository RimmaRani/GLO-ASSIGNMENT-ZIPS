package org.globallogic.os.api.service;

import java.util.UUID;

import org.globallogic.os.api.entity.Payment;
import org.globallogic.os.api.repository.PaymentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Paymentservice {

	@Autowired
	private PaymentRepository repository;

	public Payment doPayment(Payment payment) {
		payment.setTransactionId(UUID.randomUUID().toString());
		return repository.save(payment);
	}
}
